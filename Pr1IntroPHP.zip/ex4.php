<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <?php
$num = rand(1,6);
$num2 = sqrt    ($num);

echo"The square root of $num is $num2";
    ?>
</body>
</html>